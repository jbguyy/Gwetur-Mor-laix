Ceci est la page d'accueil d'un site de base généré avec le framework MkDocs et le thème Material.

> Pour voir le code MarkDown sous jacent, cliquer sur le crayon en haut à droite.

# Voici un titre de niveau 1
## Et voici un titre de niveau 2
Ceci est un paragraphe.  
Avec un retour à la ligne sans saut de ligne.

Et avec un retour à la ligne avec saut de ligne.

## Un lien :
Source pour [mkdocs-material](https://squidfunk.github.io/mkdocs-material/)

## Une image :
![illustration mkdocs-material](https://squidfunk.github.io/mkdocs-material/assets/images/illustration.png)

## Une liste :
- Toto ;
- Titi ;
- Tata...

> Libre à vous de personaliser ce site avec l'aide de ce [tutoriel pour MkDocs](https://github.com/ericECmorlaix/adn-Tutoriel_site_web)...